/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.mavenproject1;

import Telas.Tela1;

/**
 *
 * @author 23.10270-5
 */
public class Entrega2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Tela1 tela = new Tela1();
        tela.setVisible(true);
        
    }
    
}
