/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Back;

/**
 *
 * @author 23.10270-5
 */
import java.util.ArrayList;

public class Usuario {

    public ArrayList<Integer> ordenarLista(ArrayList<Integer> listaNum){
        ArrayList<Integer> listaOrdenada = new ArrayList<Integer>();
        listaOrdenada.sort(null);
        return listaOrdenada;
    }
    
    public boolean verificaNum(int num,ArrayList<Integer> listaOrdenada){
        if (listaOrdenada.contains(num)) {
            return true;
        }
        else return false;
    }
    
    public String informaBusca(int num,boolean verificacao,ArrayList<Integer> listaOrdenada){
        String x;
        if (verificacao == false) {
           x =  "Sua busca não foi encontrada";
           return x;
        }
        else{
            int val = listaOrdenada.indexOf(num);
            x  = "Sua busca foi encontrada!\nEla se encontra na posição : "+ val+" ";
            return x;
        }
    }
    
}
